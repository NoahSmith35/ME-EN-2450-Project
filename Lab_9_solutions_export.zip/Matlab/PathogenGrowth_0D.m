% Script to compute the increase in icidence of a plant pathogen (or any
% pathogen with stationary hosts).  This code is 0-D (time only) and
% predicts the growth of the pathogen for a host with a population that
% grows in size with time.
%
% The primary equations governing this are compound interest equations for
% growth:
%
% dS/dt = -beta*S*I+dP/dt
%
% dL/dt = beta*S*I-mu_L*L+e
%
% dI/dt = mu_L*L*I-mu_I*I
%
% dP/dt = dB/dt + d(leaf)/dt 
%
% dR/dt = mu_I*I
%
% with:
% S    = susceptible fraction of population (susceptible tissue)
% beta = rate of infection growth for healthy population (fraction per day)
% L    = fraction of tissue infected and latent (e.g., dormant before infection)
% I    = fraction of tissue infected and producing inoculum
% R    = fraction of tissue recovered (or removed) from population
% P    = size of the total population (plant surface area)
% B    = surface area of berries
% t    = time
% mu_L = rate of decrease in latent population (fraction per day)
% mu_I = rate of decrease in infectious population (fraction per day)
% e    = rate of import from external sources
%
% inputs: S_i (initial size of susceptible population); beta; mu;
% days (number of days to simulate); dt (time step,fraction of a day)
% output: S,I,R,time (vector of simulation times)

function [S,L,I,R,P,B] = PathogenGrowth_0D(S_i,L_i,I_i,R_i,P_i,B_i,beta,...
    mu_L_target,mu_I,e,A,T,tspan)

% pre calculate some of the temperature dependent rates
% latent period length as a function of Temperature (Calonnec et al. 2008)
%calculate temp effect array
PT   = zeros(size(T));
for i=1:length(T)
    PT(i)=Sall_temp_effect(T(i));
end
istart=1;flag=true;
mu_L = zeros(size(T));
for i=1:length(T)
    if(flag)
        PTsum = sum(PT(istart:i))*(tspan(2)-tspan(1));
        if(PTsum >= mu_L_target)
            disp(['i=',int2str(i),' and PTsum=',num2str(PTsum)])
            mu_L(istart:i)=(tspan(2)-tspan(1))*i;
            ispan = i;
            istart= istart+1;
            flag  = false;
        end
    else
        PTsum = sum(PT(istart:i))*(tspan(2)-tspan(1));
        if(PTsum >= mu_L_target)
            disp(['i=',int2str(i),' and PTsum=',num2str(PTsum)])
            mu_L(ispan:i)=(tspan(2)-tspan(1))*(i-istart);
            istart=istart+1;
            ispan=i;
        end
    end
end
mu_L=1./mu_L;
% set parameters in a cell array
p{1} = beta; %(rate of new infections)
p{2} = mu_L; %(inverse length of latent period in days)
p{3} = mu_I; %(inverse length of the infectious period in days)
p{4} = e;    %(rate of new infections from external sources)
p{5} = T;    %(temperature in C)
p{6} = tspan;%(time in days array)
p{7} = A;    %(total plant surface area at reference time)

% declare function handles
odefun = @(t,y) SLIRP_model(t,y,p);

% set initial conditions
% simulation starts when first member of the population becomes infectious
y0(1) = B_i; %(amount of population, surface area, that is berries)
y0(2) = P_i; %(total population, surface area, including berries and leaves)
y0(3) = S_i; %(initial susceptible population fraction)
y0(4) = L_i; %(initial latent population fraction)
y0(5) = I_i; %(initial infectious population fraction)
y0(6) = R_i; %(initial recovered population fraction)

% integrate using RK4 method (1st tested with Euler!)
%[~,y] = euler(odefun,tspan,y0');
[~,y] = rk4(odefun,tspan,y0');

% set outputs
B = y(:,1);
P = y(:,2);
S = y(:,3);
L = y(:,4);
I = y(:,5);
R = y(:,6);

end