%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% SLIR+P function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SLIRP_model combines all the SLIR equations and the plant growth equation 
% into one system. The dependent variables are stored in y as:
% y(1) = B (amount of population, surface area, that is berries)
% y(2) = P (total population, surface area, including berries and leaves: P = S+L+I+R)
% y(3) = S (susceptible population)
% y(4) = L (latent population)
% y(5) = I (infectious population)
% y(6) = R (recovered/removed population)
%
% and the parameters in a cell array:
% p{1} = beta_max (max rate of colony growth/new infections)
% p{2} = mu_L (length of the latent period (inverse days))
% p{3} = mu_i (inverse length of the infectious period in days)
% p{4} = e (rate of new infections from external sources)
% p{5} = T (array of temperature in C)
% p{6} = day (array of times in units of days)
% p{7} = A (total plant surface area at reference time)
%
% and the time input (idx) should be an integer for the iteration number

function [dydt] = SLIRP_model(idx,y,p)
    %assign parameters
    beta_max = p{1};
    mu_L     = p{2};
    mu_I     = 1/p{3}; %inverse of days for rate
    e        = p{4};
    T        = p{5};
    day      = p{6};
    A        = p{7};

    %assign variables
    B = y(1);
    P = y(2);
    S = y(3);
    L = y(4);
    I = y(5);
    R = y(6);
    
    %calculated parameters
    if(ceil(idx)==floor(idx)) %when we are at an interger step
        T_used = T(idx);
        day_used = day(idx);
        mu_L_used = mu_L(idx);
    else %when we are at a half step (for rk4)
        idx = floor(idx);
        T_used = 0.5*(T(idx)+T(idx+1));
        day_used = 0.5*(day(idx)+day(idx+1));
        mu_L_used = 0.5*(mu_L(idx)+mu_L(idx+1));
    end
    beta = beta_max*Sall_temp_effect(T_used); %pathogen growth rate

    %plant growth variables (Sall, 1980)
    TE = -0.35968 +0.10789*T_used-0.00214*T_used*T_used; %effective temperature
    
    dydt(1) = (0.1724*B-0.0000212*B*B)*TE;           %change in amount of berries
    dydt(2) = (1.33*(day_used+30))*TE+dydt(1); %change in P
    
    %disease variables
    dydt(3) = -beta*S*I+dydt(2)/A; %change in S
    dydt(4) = beta*S*I-mu_L_used*L+e;   %change in L
    dydt(5) = mu_L_used*L-mu_I*I;       %change in I
    dydt(6) = mu_I*I;              %change in R
    
end