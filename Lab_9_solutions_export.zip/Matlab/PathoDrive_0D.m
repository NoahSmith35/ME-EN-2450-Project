% driver script for our zero dimensional pathogen simulation
%
% load Envinronmental Forcing data (U,V,T,tspan)
load EnvironmentalForcing.mat

% set simulation constants
beta_max = 1; %max rate infection under ideal conditions (1/day)
mu_L_min = 6;    %min length of latent period (min number of days latent)
mu_I = 10;       %rate infection clears (number of days infectious)
e    = 0.001;    %rate of introduction from external sources
A    = 5000;     %normalization factor for population ('final' plant surface area in cm^2)
P_i  = 1.33*30*(-0.35968+0.10789*15-0.00214*15*15)*30;  %initial size of the population (=model after 30 days with constant temp of 15C)
S_i  = P_i/A;    %initial size of the susceptible population (normalized)
L_i  = S_i*0.01; %initial fraction of the population that is latent
I_i  = 0;        %initial fraction of the population that is infectious
R_i  = I_i*mu_I; %initial fraction of the population that is recovered
B_i  = 1;      %initial size of the berry population (assumed small (1cm^2))

% call the pathogen function
tic
[S,L,I,R,P,B]=PathogenGrowth_0D(S_i,L_i,I_i,R_i,P_i,B_i,beta_max,mu_L_min,...
    mu_I,e,A,T,tspan);
toc

% plot results
FSize = 14; %fontsize for plots
figure;plot(tspan,P/A,'-g',tspan,B/A,'--m',tspan,S,'-.k',tspan,L,'--c',tspan,I,':b',...
    tspan,R,'-.r','LineWidth',2);
legend({'Total Population';'Berry Population';'Susceptible';'Latent';'Infected';'Removed'},'Location','NorthWest');
xlabel('time (days)','Fontsize',FSize);
ylabel('Population (fraction of initial)','Fontsize',FSize)
set(gca,'Fontsize',FSize,'Xlim',[0 61]);
box on;grid on
